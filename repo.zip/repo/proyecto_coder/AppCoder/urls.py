from django.urls import path
from . import views

urlpatterns=[
    path("", views.inicio, name="inicio"),
    path("ver_cursos", views.ver_cursos, name="cursos"),#ver lista de cursos
    #path("alta_curso/<nombre>",views.alta_curso),
    path("alta_curso",views.formulario_cursos),

    path("ver_alumnos", views.ver_alumnos, name="alumnos"),
    path("alta_alumno",views.formulario_alumnos),

    path("ver_profesores", views.ver_profesores, name="profesores"),
    path("alta_profesor", views.formulario_prof),

    path("opiniones", views.opiniones, name="opiniones"),

#busquedas
    path("buscar_cursos", views.buscar_curso),
    path("buscar_alumno", views.buscar_alumno),
    path("buscar_profe", views.buscar_profe),

    path("busqueda", views.busqueda),
    path("busqueda_alumno", views.busqueda_alumno),
    path("busqueda_profs", views.busqueda_profs),

    #deletes
    path("elimina_curso/<int:id>" , views.elimina_curso , name="elimina_curso"),

    path("editar_curso/<int:id>", views.editar, name="editar_curso") #name cuando doy click
 
]