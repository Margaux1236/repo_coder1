#Formulario tipo curso
#Clase que hereda a la clase para limpiar datos, validar datos

from django import forms

class Curso_formulario(forms.Form): #clase form módulo Form
    nombre= forms.CharField(max_length=40)
    camada=forms.IntegerField()

class Alumno_formulario(forms.Form): 
    nombre= forms.CharField(max_length=40)
    matricula=forms.IntegerField()

class Profe_formulario(forms.Form): 
    nombre= forms.CharField(max_length=40)
    numero_empleado=forms.IntegerField()