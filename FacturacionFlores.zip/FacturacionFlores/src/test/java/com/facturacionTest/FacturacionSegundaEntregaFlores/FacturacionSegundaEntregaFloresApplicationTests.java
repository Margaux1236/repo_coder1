package com.facturacionTest.FacturacionSegundaEntregaFlores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturacionSegundaEntregaFloresApplicationTests {

	@Test
	void contextLoads() {
	}

}
