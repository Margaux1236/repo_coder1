package Excepciones;

public class ClientNotFoundExceptions extends RuntimeException {

    public ClientNotFoundExceptions(String message) {
        super(message);

}

}