package Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import DTO.DTOCliente;
import Models.ModelCliente;
import Servicio.IClienteServicio;



@RestController
@RequestMapping("/clientes")

public class ClienteController {

    @Autowired
    IClienteServicio clienteServicio;

    @GetMapping("/get_clientes/id/{id}")
    public ResponseEntity<ModelCliente> obtenerClientePorID(Long id) {
        return ResponseEntity.ok(clienteServicio.obtenerClientePorID(id));
    }

    @DeleteMapping("/delete_cliente/{id}")
    public void eliminarCliente(Long id) {
        clienteServicio.eliminarCliente(id);
    }

    @PutMapping("/update_cliente/{id}")
    public void actualizarCliente(Long id, DTOCliente cliente) {
        clienteServicio.actualizarCliente(id, cliente);
    }


}
