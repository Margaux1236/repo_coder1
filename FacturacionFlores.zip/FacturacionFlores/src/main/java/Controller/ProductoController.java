package Controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import DTO.DTOProducto;
import Models.ModelProducto;
import Servicio.ProductoServicio;



@RestController

public class ProductoController {

    @Autowired
    ProductoServicio productoServicio;

    @GetMapping("/get_productos")
    public List<ModelProducto> obtenerProductos() {
        return productoServicio.obtenerProductos();
    }

    @GetMapping("/get_productos/categoria/{categoria}")
    public List<ModelProducto> obtenerProductosPorCategoria(String categoria) {
        return productoServicio.obtenerProductosPorCategoria(categoria);
    }

    @GetMapping("/get_productos/precio/{precio}")
    public List<ModelProducto> obtenerProductosPorPrecio(BigDecimal precio) {
        return productoServicio.obtenerProductosPorPrecio(precio);
    }

    @GetMapping("/get_producto/{id}")
    public ModelProducto obtenerProductoPorID(Long id) {
        return productoServicio.obtenerProductoPorID(id);
    }

    @DeleteMapping("/delete_producto/{id}")
    public void eliminarProducto(Long id) {
        productoServicio.eliminarProducto(id);
    }

    @PutMapping("/update_producto/{id}")
    public void actualizarProducto(Long id, DTOProducto producto) {
        productoServicio.actualizarProducto(id,producto);
    }

    

}
