package Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import Models.ModelFactura;
import Servicio.FacturaServicio;

@RestController
public class FacturaController {

    @Autowired
    FacturaServicio facturaServicio;

    @GetMapping("/get_facturas")
    public List<ModelFactura> obtenerFacturas() {
        return facturaServicio.obtenerFacturas();
    }

    @PostMapping("/post_factura")
    public ModelFactura crearFactura(ModelFactura factura) {
        return facturaServicio.crearFactura(factura);
    }

    @PostMapping("/put_factura")
    public ModelFactura actualizarFactura(Long id, ModelFactura factura) {
        return facturaServicio.actualizarFactura(id, factura);
    }

    @PostMapping("/delete_factura")
    public void eliminarFactura(Long id) {
        facturaServicio.eliminarFactura(id);
    }

    @GetMapping("/get_factura")
    public ModelFactura obtenerFactura(Long id) {
        return facturaServicio.obtenerFactura(id);
    }

}
