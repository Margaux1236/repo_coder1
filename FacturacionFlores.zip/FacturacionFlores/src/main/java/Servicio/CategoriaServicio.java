package Servicio;

import java.util.List;

import ch.qos.logback.core.model.Model;

public interface CategoriaServicio {

    Model crearCategoria(Model model);
    Model actualizarCategoria(Model model);
    Model obtenerCategoria(Long id);
    void eliminarCategoria(Long id);
    List<Model> obtenerCategorias();

}
