package Servicio;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Repository.RepositoryFactura;



@Service

public class VentaServicio {

    @Autowired
    RepositoryFactura repositoryFactura;

    @Autowired
    ClienteServicio clienteServicio;

    @Autowired
    ProductoServicio productoServicio;

    @Autowired
    CategoriaServicio categoriaServicio;    

    



}
