package Servicio;

import java.math.BigDecimal;
import java.util.List;

import DTO.DTOProducto;
import Models.ModelProducto;



public interface IProductoServicio {

    ModelProducto crearProducto(ModelProducto producto);

    public ModelProducto actualizarProducto(Long id, DTOProducto producto);

    ModelProducto obtenerProductoPorID(Long id);

    ModelProducto obtenerPrecio (ModelProducto precio);

    void eliminarProducto(Long id);

    void updateProducto(ModelProducto producto, Long id);

    List<ModelProducto> obtenerProductos();

    List<ModelProducto> obtenerProductosPorCategoria(String categoria);

    List<ModelProducto> obtenerProductosPorPrecio(BigDecimal precio);

    

}
