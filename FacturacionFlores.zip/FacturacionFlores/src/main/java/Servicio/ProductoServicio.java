package Servicio;

import java.math.BigDecimal;
import java.util.List;

import java.util.Optional;

import org.springframework.stereotype.Service;

import DTO.DTOProducto;
import Excepciones.ProductNotFoundException;
import Models.ModelProducto;
import Repository.RepositoryProducto;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductoServicio implements IProductoServicio {

    private final RepositoryProducto repositoryProducto;

    public ModelProducto crearProducto (ModelProducto producto) {
        return repositoryProducto.save(producto);
    }


    @Override
    public ModelProducto actualizarProducto(Long Id, DTOProducto producto) {
        ModelProducto existingProducto = obtenerProductoPorID(Id);
        existingProducto.setNombre(producto.getNombre());
        existingProducto.setPrecio(producto.getPrecio());
        existingProducto.setCantidadStock(producto.getCantidadStock());
        return repositoryProducto.save(existingProducto);
    }


    @Override
    public ModelProducto obtenerProductoPorID(Long id) {
    Optional<ModelProducto> producto = repositoryProducto.findById(id);
    return producto.orElseThrow(() -> new ProductNotFoundException("Producto no encontrado"));

}



@Override
public ModelProducto obtenerPrecio(ModelProducto precio) {
    return repositoryProducto.findByPrecioModelProducto(precio.getPrecio().doubleValue());
}

    @Override
    public void eliminarProducto(Long id) {
    Optional<ModelProducto> productopcional = repositoryProducto.findById(id);
    productopcional.ifPresentOrElse(
        product -> repositoryProducto.delete(product),
        () -> { throw new ProductNotFoundException("Producto no encontrado"); }
    );
}

   

    @Override
    public void updateProducto(ModelProducto producto, Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateProducto'");
    }

    @Override
    public List<ModelProducto> obtenerProductos() {
        return repositoryProducto.findAll();
    }

    @Override
    public List<ModelProducto> obtenerProductosPorCategoria(String categoria) {
        return repositoryProducto.findByCategoria(categoria);
    }

    @Override
    public List<ModelProducto> obtenerProductosPorPrecio(BigDecimal precio) {
        return repositoryProducto.findByPrecioModelProducto(precio);
    }

}
