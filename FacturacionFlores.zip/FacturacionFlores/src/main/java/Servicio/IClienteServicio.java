package Servicio;

import java.util.List;

import DTO.DTOCliente;
import Models.ModelCliente;

public interface IClienteServicio {

    ModelCliente crearCliente(ModelCliente cliente);


    ModelCliente obtenerClientePorID(Long id);

    public ModelCliente actualizarCliente(Long Id, DTOCliente cliente);

    void eliminarCliente(Long id);


    List<ModelCliente> obtenerFactura(Long id);



}
