package Servicio;

import java.util.List;



import Models.ModelVentaProducto;


public interface IVentaServicio {

    ModelVentaProducto crearVenta(ModelVentaProducto ventaProducto);
    ModelVentaProducto actualizarVenta(ModelVentaProducto ventaProducto);
    ModelVentaProducto obtenerVenta(Long id);
    void eliminarVenta(Long id);
    List<ModelVentaProducto> obtenerVentas();
    ModelVentaProducto obtenerVentaPorProducto(Long id);
    ModelVentaProducto obtenerVentaPorFactura(Long id);
    

}
