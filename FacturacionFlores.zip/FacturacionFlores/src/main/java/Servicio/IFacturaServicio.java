package Servicio;

import java.util.List;

import Models.ModelFactura;

public interface IFacturaServicio {


    ModelFactura crearFactura(ModelFactura factura);
    public ModelFactura actualizarFactura(Long id, ModelFactura factura);
    ModelFactura obtenerFactura(Long id);
    void eliminarFactura(Long id);
    List<ModelFactura> obtenerFacturas();
    public List<ModelFactura> obtenerFacturaPorCliente(Long id);

}
