package Servicio;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;


import Excepciones.FacturaNotFoundException;
import Models.ModelFactura;

import Repository.RepositoryFactura;
import lombok.NoArgsConstructor;

@Service
@NoArgsConstructor

public class FacturaServicio implements IFacturaServicio {

    private RepositoryFactura repositoryFactura;

    @Override
    public ModelFactura crearFactura(ModelFactura factura) {
        return repositoryFactura.save(factura);
    }
    
    

    @Override
    public ModelFactura actualizarFactura(Long id, ModelFactura factura) {
        ModelFactura existingFactura = obtenerFactura(id);
        existingFactura.setFecha(factura.getFecha());
        return repositoryFactura.save(existingFactura);
    }
        


    @Override
    public ModelFactura obtenerFactura(Long id) {
        Optional<ModelFactura> factura = repositoryFactura.findById(id);
        return factura.orElseThrow(() -> new FacturaNotFoundException("Factura no encontrada"));
        
    }

    @Override
    public void eliminarFactura(Long id) {
        Optional<ModelFactura> factura = repositoryFactura.findById(id);
        factura.ifPresentOrElse(
            fact -> repositoryFactura.delete(fact),
            () -> { throw new FacturaNotFoundException("Factura no encontrada"); }
        );
        
    }

    @Override
    public List<ModelFactura> obtenerFacturas() {
        return repositoryFactura.findAll();
    }

    @Override
    public List<ModelFactura> obtenerFacturaPorCliente(Long id) {
        List<ModelFactura> facturas = repositoryFactura.findAll();
        // filter facturas by cliente id
        return facturas.stream()
                .filter(factura -> factura.getCliente().getId().equals(id))
                .collect(Collectors.toList());
}


}
