package Servicio;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import DTO.DTOCliente;
import Excepciones.ClientNotFoundExceptions;
import Models.ModelCliente;

import Repository.RepositoryCliente;
import lombok.NoArgsConstructor;

@Service
@NoArgsConstructor

public class ClienteServicio implements IClienteServicio {

    private RepositoryCliente repositoryCliente;

   @Override
    public ModelCliente crearCliente(ModelCliente cliente) {
        return repositoryCliente.save(cliente);
    }
    

    @Override
    public ModelCliente obtenerClientePorID(Long id) {
        Optional<ModelCliente> cliente = repositoryCliente.findById(id);
        return cliente.orElseThrow(() -> new ClientNotFoundExceptions("Cliente no encontrado"));
    }

    
    
    
    @Override
    public void eliminarCliente(Long id) {
        Optional<ModelCliente> clientopcional = repositoryCliente.findById(id);
        clientopcional.ifPresentOrElse(
            client -> repositoryCliente.delete(client),
            () -> { throw new ClientNotFoundExceptions("Cliente no encontrado"); }
        );
    }





    @Override
    public List<ModelCliente> obtenerFactura(Long id) {
        return repositoryCliente.obtenerFactura(id);
        
    }


    @Override
    public ModelCliente actualizarCliente(Long Id, DTOCliente cliente) {
        ModelCliente existingCliente = obtenerClientePorID(cliente.getId());
        existingCliente.setNombre(cliente.getNombre());
        existingCliente.setApellido(cliente.getApellido());
        // Add other fields to update
        return repositoryCliente.save(existingCliente);
    }

}






