package DTO;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor


public class DTOProducto {

    private String nombre;
    private BigDecimal precio;
    private int cantidadStock;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }   

    public String getNombre() {
        return nombre;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }       

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setCantidadStock(int cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public int getCantidadStock() {
        return cantidadStock;
    }

      

}
