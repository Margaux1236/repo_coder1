package DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class DTOVenta {


    private DTOProducto producto;
    private int cantidadVendida; 

    public void setProducto(DTOProducto producto) {
        this.producto = producto;
    }

    public DTOProducto getProducto() {
        return producto;
    }

    public void setCantidadVendida(int cantidadVendida) {
        this.cantidadVendida = cantidadVendida;
    }

    public int getCantidadVendida() {
        return cantidadVendida;
    }


        

}
