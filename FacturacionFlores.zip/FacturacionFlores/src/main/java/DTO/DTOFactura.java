package DTO;

import java.math.BigDecimal;
import java.time.LocalDate;

import Models.ModelCliente;
import Models.ModelProducto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor


public class DTOFactura {

    private Long id;
    private LocalDate fecha;
    private ModelCliente cliente;
    private ModelProducto producto;
    private BigDecimal precio;
    private int cantidadVendida;
    private Double total;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {        
        return id;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalDate getFecha() {
        return fecha;
    }       


    public void setCliente(ModelCliente cliente) {
        this.cliente = cliente;
    }

    public ModelCliente getCliente() {
        return cliente;
    }       

    public void setProducto(ModelProducto producto) {
        this.producto = producto;
    }   

    public ModelProducto getProducto() {        
        return producto;
    }   

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }   

    public BigDecimal getPrecio() {        
        return precio;

    }

    public void setCantidadVendida(int cantidadVendida) {
        this.cantidadVendida = cantidadVendida;
    }   
    
    public int getCantidadVendida() {        
        return cantidadVendida;
    }


}
