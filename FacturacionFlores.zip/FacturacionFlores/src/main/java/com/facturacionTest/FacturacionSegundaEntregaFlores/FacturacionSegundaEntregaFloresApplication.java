package com.facturacionTest.FacturacionSegundaEntregaFlores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturacionSegundaEntregaFloresApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacturacionSegundaEntregaFloresApplication.class, args);
	}

}
