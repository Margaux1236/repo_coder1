package Repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import Models.ModelCliente;

@Repository
public interface RepositoryCliente extends CrudRepository<ModelCliente, Long> {

    public Optional<ModelCliente> findById(Long id); 
    public List<ModelCliente> findAll();    
    public ModelCliente findByNombre(String nombre);
    public ModelCliente findByEmail(String email);
    public ModelCliente findByApellido(String apellido);
    public List<ModelCliente> obtenerFactura(Long id);



}
