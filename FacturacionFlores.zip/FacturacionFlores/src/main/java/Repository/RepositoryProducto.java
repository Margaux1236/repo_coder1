package Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import Models.ModelProducto;

@Repository

public interface RepositoryProducto extends CrudRepository<ModelProducto, Long> {

    public Optional<ModelProducto> findById(Long id);
    public List<ModelProducto> findAll(); 
    public List<ModelProducto> findByPrecioModelProducto(BigDecimal precio);
    public ModelProducto findBycantidadStock(int cantidadStock);
    public List<ModelProducto> findByCategoria(String categoria);
    public ModelProducto findByPrecioModelProducto(double doubleValue);

}
