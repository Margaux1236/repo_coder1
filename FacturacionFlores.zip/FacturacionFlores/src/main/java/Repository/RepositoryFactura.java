package Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import Models.ModelCliente;
import Models.ModelFactura;

@Repository

public interface RepositoryFactura extends CrudRepository<ModelFactura, Long> {

    public List<ModelFactura> findAll();
    public Optional<ModelFactura> findById(Long id);
    public List<ModelFactura> findByCliente(ModelCliente cliente);
    public List<ModelFactura> findByFechaFacturas(LocalDate fecha);
    public List<ModelFactura> obtenerFactura(Long id);
    
    



}
