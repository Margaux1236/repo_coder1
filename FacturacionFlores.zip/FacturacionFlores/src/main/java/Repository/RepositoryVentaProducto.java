package Repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import Models.ModelVentaProducto;


@Repository
public interface RepositoryVentaProducto {

    public ModelVentaProducto findById(Long id);
    public List<ModelVentaProducto> findAll();
   

}
