package Repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import Models.ModelCategoria;



@Repository
public interface RepositoryCategoria {

    public ModelCategoria findById(Long id);
    public List<ModelCategoria> findAll();

}
