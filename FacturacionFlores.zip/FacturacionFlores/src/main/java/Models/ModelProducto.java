package Models;

import java.math.BigDecimal;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "PRODUCTO")
// @NoArgsConstructor
// @AllArgsConstructor

public class ModelProducto {

    @Id
    @Column(name = "ID_PRODUCTO")
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;


    @Column(name="NOMBRE")
    private String nombre;

    @Column(name="PRECIO")
    private BigDecimal precio;

    @Column(name="CANTIDAD_STOCK")
    private int cantidadStock;


    

    //RELACIONES CON OTRAS TABLAS
     @ManyToOne(optional = false)
     @JoinColumn(name = "ID_FACTURA")
    private ModelFactura factura;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_CATEGORIA")
    private ModelCategoria categoria;

   

    @OneToMany(mappedBy = "producto")
    private List<ModelVentaProducto> venta_productos;
    

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
   
    
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public BigDecimal getPrecio() {
        return precio;
    }
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }
    public int getCantidadStock() {
        return cantidadStock;
    }
    public void setCantidadStock(int cantidadStock) {
        this.cantidadStock = cantidadStock;
    }
    
}

    


    


