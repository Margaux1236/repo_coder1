package Models;

import java.util.List;
import jakarta.persistence.Column;  
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "CATEGORIAS_PRODUCTOS")



public class ModelCategoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CATEGORIA")
    private Long id;

    @Column(name = "CATEGORIA")
    private String categoria;

    @OneToMany(mappedBy = "categoria_productos")
    private List<ModelProducto> productos;

    //Constructor

    public ModelCategoria(Long id, String categoria, List<ModelProducto> productos) {
        this.id = id;
        this.categoria = categoria;
        this.productos = productos;
    }

    //Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public List<ModelProducto> getProductos() {
        return productos;
    }

    public void setProductos(List<ModelProducto> productos) {
        this.productos = productos;
    }

    


}



