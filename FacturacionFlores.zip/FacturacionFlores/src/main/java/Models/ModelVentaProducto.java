package Models;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "VENTA")

public class ModelVentaProducto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_VENTA")
    private Long id;

    @Column(name="CANTIDAD_VENDIDA")
    private int cantidadVendida;

    @ManyToOne(optional = false)
    @JoinColumn(name = "ID_PRODUCTO")
    private ModelProducto producto;

    
    //No estoy muy segura de esto XD
    @OneToMany(mappedBy = "ventaProducto")
    private List<ModelFactura> facturas;


    //Constructor
    public ModelVentaProducto(Long id, int cantidadVendida, ModelProducto producto) {
        this.id = id;
        this.cantidadVendida = cantidadVendida;
        this.producto = producto;
    }

    //Getters y Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getCantidadVendida() {
        return cantidadVendida;
    }

    public void setCantidadVendida(int cantidadVendida) {
        this.cantidadVendida = cantidadVendida;
    }

    public ModelProducto getProducto() {
        return producto;
    }

    public void setProducto(ModelProducto producto) {
        this.producto = producto;
    }

    


    

}
