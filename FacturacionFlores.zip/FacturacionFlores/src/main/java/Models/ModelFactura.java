package Models;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "FACTURA")

public class ModelFactura {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_FACTURA")
    private Long id;


    @Column(name = "FECHA")
    private LocalDate fecha;

    //La relacionamos con el cliente por medio del id; por lp tanto, debe ser la clase ModelCliente
    
    @ManyToOne
    @JoinColumn(name = "ID_CLIENTE")
    private ModelCliente cliente;

    @ManyToOne
    @JoinColumn(name = "ID_VENTA")
    private ModelVentaProducto venta;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public ModelCliente getCliente() {
        return cliente;
    }

    public void setCliente(ModelCliente cliente) {
        this.cliente = cliente;
    }


    

    



}
