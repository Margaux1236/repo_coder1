from django.shortcuts import render
#esto fue añadido
from AppCoder.models import Curso, Avatar
from AppCoder.models import Alumno
from AppCoder.models import Profesor
from django.http import HttpResponse
from django.template import loader
from AppCoder.forms import Curso_formulario, UserEditForm
from AppCoder.forms import Alumno_formulario
from AppCoder.forms import Profe_formulario
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm #estas dos son clases
from django.contrib.auth import login, authenticate
#esas son funciones...login y authenticate
from django.contrib.auth.decorators import login_required


# Create your views here.

#esta corresponde al path inicio

def inicio(request):
    return render( request , "padre.html")

#llega la peticion hago render del html, o sea, lo que voy a mostrar
#render manda el resultado

def alta_curso(request, nombre):
    #Creo un curso con el constructor de la clase Curso
    curso = Curso(nombre=nombre, camada=2353)
    #curso.save()genera un nuevo registro en la base de datos
    curso.save()
    texto=f"Se guardó en la BD el curso: {curso.nombre} {curso.camada}"
    return HttpResponse(texto)

#@ login_required
def ver_cursos(request):
    #Cómo obtener lo que está en mi BD :P
    #Los modelos se comunican con la BD
    cursos =Curso.objects.all()#retorna toda la lista de cursos
    #eso se mete a un diccionario
    avatares=Avatar.objects.filter(user=request.user.id)
    #dicc_cursos={"cursos":cursos} #hay que comunicar el dicc con el template para que haga algo
    #plantilla = loader.get_template("cursos.html")#acceder al template
    #documento=plantilla.render(dicc_cursos) #render de la plantilla y le mando el conjunto de cursos
    #en el render le debo insertar una lista dinámica 
    #el docu es listo para mostrar al usuario
    return render(request,"cursos.html",{"url":avatares[0].imagen.url, "cursos":cursos})


def alta_alumno(request,nombre):
    alumno = Alumno(nombre=nombre, matricula=4567)
    alumno.save()
    texto=f"Se guardó en la BD el alumno: {alumno.nombre} {alumno.matricula}"
    return HttpResponse(texto)

def ver_alumnos(request):
    alumnos=Alumno.objects.all()
    #trae todos los objetos de tipo Alumno
    avatares=Avatar.objects.filter(user=request.user.id)
    '''dicc_alumnos={"alumnos":alumnos}
    plantilla_alum= loader.get_template("alumnos.html")
    documento_alum=plantilla_alum.render(dicc_alumnos)'''
    return render(request,"alumnos.html",{"url":avatares[0].imagen.url,"alumnos":alumnos})
    #return HttpResponse(documento_alum)


def alta_profesor(request, nombre):
   
    profesor = Profesor(nombre=nombre, numero_empleado=2353)
    profesor.save()
    texto=f"Se guardó en la BD el profesor: {profesor.nombre} {profesor.numero_empleado}"
    return HttpResponse(texto)

def ver_profesores(request):
    profesores=Profesor.objects.all()
    avatares=Avatar.objects.filter(user=request.user.id)
    '''dicc_profes={}
    plantilla_profes=loader.get_template("profesores.html")
    documento_profes=plantilla_profes.render(dicc_profes)
    return HttpResponse(documento_profes)'''
    return render(request,"profesores.html",{"url":avatares[0].imagen.url,"profesores":profesores})

def opiniones(request):
    return render (request, "opiniones.html")

def formulario_cursos(request):

    if request.method == "POST":

        mi_formulario=Curso_formulario( request.POST)
        
        #FUNCIONALIDADES DEL FORMULARIO EJEMPLO:
        if mi_formulario.is_valid():#revirsar si lo que añado corresponde al formato que se pidió
        #true=da alta
        #false= no 
            datos=mi_formulario.cleaned_data #del objeto rquest uso post y guardo nombre, por ejemplo
            #clear_data-> diccionario con los datos del formulario limpios; por lo tanto tiene formato {llave:valor}
            curso= Curso(nombre=datos["nombre"] , camada=datos["camada"])
            curso.save()
            return render(request, "formulario_cursos.html" )


    return render(request, "formulario_cursos.html")

def formulario_alumnos(request):

    if request.method == "POST":

        mi_formulario_alumno=Alumno_formulario(request.POST)

        if mi_formulario_alumno.is_valid():

            datos_alumno=mi_formulario_alumno.cleaned_data
            alumno = Alumno(nombre=datos_alumno["nombre"] , matricula=datos_alumno["matricula"])
            alumno.save()
            return render(request, "formulario_alumnos.html")
    
    return render(request, "formulario_alumnos.html")

def formulario_prof(request):

    if request.method == "POST":#ver que es POST

        mi_formulario_prof=Profe_formulario(request.POST)

        if mi_formulario_prof.is_valid():

            datos_profesor=mi_formulario_prof.cleaned_data

            profesor= Profesor(nombre=datos_profesor["nombre"] , numero_empleado=datos_profesor["numero_empleado"])
            profesor.save()
            return render(request, "formulario_prof.html")


    return render(request, "formulario_prof.html")



def buscar_alumno(request):

    return render(request, "buscar_alumno.html")

def buscar_curso(request):

    return render(request, "buscar_curso.html")


def buscar_profe (request):

    return render(request, "buscar_profe.html")


def busqueda(request):

    #si en formulario está el campo nombre
    if request.GET["nombre"]:
        nombre=request.GET["nombre"]
        #del modelo curso quiero modelo curso filtrado si el nombre contiene lo que viene del formulario buscar_curso
        cursos=Curso.objects.filter(nombre__icontains=nombre)
        return render(request, "resultado_busqueda.html", {"cursos":cursos})
    
    #busco, si formulario no vacio, busco en la BD, llegan los resultados y eso lo mando a un html
    
    else:
        return HttpResponse("Ingrese el nombre del curso")

def busqueda_alumno(request):

    if request.GET["nombre_alum"]:
        nombre_alum=request.GET["nombre_alum"]
        alumnos=Alumno.objects.filter(nombre__icontains=nombre_alum)
        return render(request, "resultado_busqueda_alum.html", {"alumnos":alumnos})
    
    else:
        return HttpResponse("Ingrese un nombre válido")
    

def busqueda_profs(request):
    if request.GET["nombre"]:
        nombre=request.GET["nombre"]
        profesores=Profesor.objects.filter(nombre__icontains=nombre)#son dos _ en icontains
        return render(request, "resultado_busqueda_profes.html", {"profesores":profesores})

    else:
        return HttpResponse("Escriba un nombre valido")

@login_required
def elimina_curso(request, id):
    
    curso = Curso.objects.get(id=id)
    curso.delete()
    curso= Curso.objects.all()

    return render(request, "cursos.html", {"cursos" : curso})

@login_required
def editar(request , id):
    curso = Curso.objects.get(id=id)
    if request.method == "POST":
        mi_formulario = Curso_formulario( request.POST )
        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data
            curso.nombre = datos["nombre"]
            curso.camada = datos["camada"]
            curso.save()
            curso = Curso.objects.all()
            return render(request , "cursos.html" , {"cursos":curso})

        
    else:
        mi_formulario = Curso_formulario(initial={"nombre":curso.nombre , "camada":curso.camada})
    
    return render( request , "editar_curso.html" , {"mi_formulario": mi_formulario , "curso":curso})

def login_request(request):
    if request.method == "POST":
        #aqui va la validacion
        #post de login

        #formulario autenticacion
        form=AuthenticationForm(request, data=request.POST)#datos del input datos del formulario, los que vienen del POST
        
        if form.is_valid(): #si datos son validos, o sea, formato solicitado de nombre usuario y contraseña

#cleaned data siempre devuelve diccionario
            usuario= form.cleaned_data.get("username")
            contra=form.cleaned_data.get("password")
            #una vez revisados datos correctos, esa data limpia devuelve un formato esos datos 

#funcion authenticate retorna un objeto usuario, msndo credenciales, si existe el usuario, listo
            user=authenticate(username=usuario, password=contra)

            if user is not None: #o sea si esí existe
                login(request, user)
                avatares = Avatar.objects.filter(user=request.user.id)
                return render( request , "inicio.html" , {"url":avatares[0].imagen.url})
                
                #,"mensaje":f"Bienvenido/a {usuario}", "usuario":usuario#
                                                        
            #render manda mensaje a inicio.html
            else: #credenciales bien pero no hay usuario con esos datos
                return HttpResponse(f"Usuario no encontrado")
        else:
            return HttpResponse(f"Form INCORRECTO {form}")



    form= AuthenticationForm()
    #formulario para validar, se renderiza template login y se le manda el formulario de autenticacion de django
    return render (request, "login.html", {"form":form})

def register(request):
    

    if request.method == "POST":
        form= UserCreationForm(request.POST)

        if form.is_valid():
            form.save()#se guarda el registro
            return HttpResponse("Usuario creado")

    else: 
        form = UserCreationForm()
    
    return render(request, "registro.html", {"form":form})



def editarPerfil(request):

    usuario = request.user

    if request.method == "POST":
        mi_formulario = UserEditForm(request.POST)

        if mi_formulario.is_valid():

            informacion=mi_formulario.cleaned_data
            #en la var informacion guardo los datos limpios de mi formulario
            #cleaned data devuelve un dicc
            usuario.email=informacion["email"]
            password=informacion["password"]
            usuario.set_password(password)
            usuario.save()
            return render (request, "inicio.html")

            #se toma a usuario que vino de la petición y cambio su data


    else:
        miFormulario = UserEditForm(initial={"email":usuario.email})
    
    return render( request , "editar_perfil.html", {"miFormulario":miFormulario, "usuario":usuario})

#Se llama a Editar perfil estando en el login. Si no estoy logueado, no se verá
#Doy click en editar /tipo get/ se crea el formulario EditForm
#se renderiza el template editar perfil, se le comparte un dicc con edicion